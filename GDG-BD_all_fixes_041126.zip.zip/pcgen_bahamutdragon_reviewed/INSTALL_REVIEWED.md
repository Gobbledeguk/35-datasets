# BahamutDragon PCGen data – reviewed edition (complete, plug and play)

This is the complete BahamutDragon PCGen repository (https://github.com/bahamutdragon/pcgen, commit d353e9b, all game
systems) with the reviewed and extended D&D 3.5 and Dark Sun data already applied. Nothing else is needed.

## Installation (as in BahamutDragon's README.md)
1. Unzip this archive somewhere outside your PCGen installation (or into a data folder PCGen recognizes).
2. Copy the contents of `system/gameModes` into your PCGen installation's `system/gameModes` folder (add, don't replace –
   PCGen's own game modes such as plain 35e stay). This adds the Bahamut35e, Bahamut3e, Darksun35e and other game modes.
3. In PCGen: Tools > Preferences > Location, point the data directory to this archive's `data` folder (or copy `data` into
   your PCGen data folder).
4. Optionally copy `outputsheets` and `preview` into the matching PCGen folders.
5. Start PCGen, Select Sources > Advanced, choose the game (e.g. 35e or Bahamut35e) and the books.

Tested with PCGen 6.08.00 RC10.

## What differs from BahamutDragon's repository
Only `data/35e` and `data/darksun_35e` (1,252 files: 272 changed, 156 new); everything else is BahamutDragon's, unchanged.
- Reviewed and fixed: feats, spells (Player's Handbook structure), psionic powers, maneuvers, equipment, classes, deities,
  ability categories, Tome of Magic, Magic of Incarnum, Complete Champion churches, Forgotten Realms deities.
- Added: the Dragon Magazine Compendium (`data/35e/paizo/dragon_magazine_compendium`), the Arms and Equipment Guide
  converted for 3.5 (campaign key "Arms and Equipment Guide (3.5)"), and the Sovereign Press Dragonlance books Age of
  Mortals and Legends of the Twins.
- `REVIEW_NOTES/` – what was changed in each review, and what still needs the books.
