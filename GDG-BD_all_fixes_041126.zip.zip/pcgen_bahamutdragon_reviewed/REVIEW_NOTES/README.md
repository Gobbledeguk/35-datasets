# BahamutDragon PCGen data – reviewed 3.5e and Dark Sun version

A complete copy of the 3.5e and Dark Sun data of https://github.com/bahamutdragon/pcgen
(base commit d353e9b), with the fixes from the feat and spell review applied. Books that were not
changed are copied unchanged, so this folder can replace the repository's `data/35e`,
`data/darksun_35e` and the two game modes on its own.

## Contents

| Path | Content |
|---|---|
| `data/35e/` | All 3.5e books. 284 files differ from the repository (feat review, spell/power/maneuver conversion, Spell Compendium rule, Magic of Eberron spells and powers); everything else is a byte-identical copy. |
| `data/35e/paizo/dragon_magazine_compendium/` | New book: the Dragon Magazine Compendium, converted from the PDF (its own `CONVERSION_NOTES.txt`). |
| `data/35e/wizards_of_the_coast/supplement/arms_and_equipment/` | New in 3.5: the 3e Arms and Equipment Guide converted for 3.5 (see `3E_BOOKS_NOTES.md`). |
| `data/35e/sovereign_press/dragonlance/` | Age of Mortals and Legends of the Twins (Sovereign Press), from Gobbledeguk/35-datasets, brought in line with this data set (see `DRAGONLANCE_PACKS_NOTES.md`). |
| `data/darksun_35e/` | Dark Sun Campaign Setting and Terrors of Athas, reviewed. |
| `data/_universal/` | Unchanged from the repository: shared race, deity and data-control files that 3.5e books load with `*/_universal/…` (needed even when those books are not selected). |
| `data/_artwork/` | The four cover and logo images that 3.5e PCCs reference (the repository's full artwork folder is optional and not included). |
| `system/gameModes/Bahamut35e/`, `system/gameModes/Darksun35e/` | Unchanged from the repository. The plain `35e` game mode (used by Dark Sun) ships with PCGen. |
| `REVIEW_NOTES/` | This file, `DRAGONLANCE_PACKS_NOTES.md` (the two Sovereign Press packs), `TOME_OF_MAGIC_NOTES.md` (Tome of Magic), `COMPLETE_CHAMPION_NOTES.md` (Complete Champion churches), `FR_DEITIES_NOTES.md` (Forgotten Realms deities), `INCARNUM_NOTES.md` (Magic of Incarnum; ability categories in all books), `OBJECT_TYPES_NOTES.md` (classes, races, skills, domains, deities, templates), `EQUIPMENT_NOTES.md` (equipment against the Player's Handbook), `3E_BOOKS_NOTES.md` (3e books: Forgotten Realms comparison, Epic Level Handbook check, Arms and Equipment Guide), `SPELL_FIXES_NOTES.md` (spell, power and maneuver work), `repo_feat_review_open_questions.md` (decisions and data gaps), `repo_feat_review_learnings.md`. Not read by PCGen. |

## Installing

Copy `data/35e`, `data/darksun_35e`, `data/_universal` (and optionally `data/_artwork`) and `system/gameModes/Bahamut35e`, `Darksun35e` over (or instead of) the
same folders of a PCGen installation that uses the BahamutDragon data. Do not mix with the repository's
own copies of these folders – each book should exist once.

## Verification

Loaded as a standalone installation in PCGen 6.08.00RC10: Bahamut35e and 35e (Dark Sun) game modes, with the
same results as the tested tree (spells, powers and maneuvers dumped from PCGen's own model; load messages
identical). See the notes for what was changed and what remains open.
